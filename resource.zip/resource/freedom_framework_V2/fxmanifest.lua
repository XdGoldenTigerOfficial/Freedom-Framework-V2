-- ------------------------------ --
-- ---  COPYRIGHT/OWNER INFO  --- --
--  Author: Xd_Golden_Tiger#0001  --
-- ------------------------------ --

fx_version 'cerulean'
game 'gta5'

author 'Xd_Golden_Tiger'
description 'The official V2 for the Freedom Framework originally created by AbelGaming'
version '0.0.1'

client_scripts {
	'client/FreedomFramework.Client.net.dll'
}

server_scripts {
	'server/FreedomFramework.Server.net.dll'
}

files {
	'**/*.dll',
	'server/db/auto.sql'
}

auto_sql_file 'server/db/auto.sql'